import express, { Request, Response } from 'express';

import bodyParser from 'body-parser';
import pool from './pgconfig';

import { filterPassedStudents, getStudentNames, sortStudentsByGrade, getAverageAge } from './service';

const app = express();
const port = process.env.PORT || 3000;


app.use(bodyParser.json());

app.post('/process-orders', async (req: Request, res: Response) => {
    const { items } = req.body;

    if (!items) {
        return res.status(400).json({ error: 'Items list is required' });
    }

    try {
        const filteredOrders = items.filter((order: { orderBlocks: { LineNo: number; }[]; }) => 
            !order.orderBlocks.some(block => block.LineNo % 3 === 0)
        );

        const client = await pool.connect();
        try {
            await client.query('BEGIN');
            for (const order of filteredOrders) {
                const { orderID } = order;
                await client.query('INSERT INTO orders (orderID) VALUES ($1)', [orderID]);
            }
            await client.query('COMMIT');
            res.status(200).json({ message: 'Orders processed and stored successfully' });
        } catch (err) {
            await client.query('ROLLBACK');
            console.error('Error during transaction:', err);
            res.status(500).json({ error: 'An error occurred while processing the orders' });
        } finally {
            client.release();
        }
    } catch (err) {
        console.error('Error connecting to database:', err);
        res.status(500).json({ error: 'An error occurred while processing the orders' });
    }
});


const students = [
    { name: "Niranjanee", age: 20, grade: 75 },
    { name: "Arati", age: 22, grade: 85 },
    { name: "Chaitrali", age: 21, grade: 60 },
    { name: "Sarthak", age: 19, grade: 45 },
    { name: "Rohit", age: 20, grade: 90 }
];

app.get('/passed-students', (req, res) => {
    const result = filterPassedStudents(students);
    res.json(result);
});

app.get('/get-student-names', (req, res) => {
    const result = getStudentNames(students);
    res.json(result);
});

app.get('/sort-students-by-grade', (req, res) => {
    const result = sortStudentsByGrade(students);
    res.json(result);
});

app.get('/get-average-age', (req, res) => {
    const result = getAverageAge(students);
    res.json(result);
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
