"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// src/pgconfig.ts
const pg_1 = require("pg");
const pool = new pg_1.Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'week3',
    password: 'postgresql',
    port: 5432, // Use your PostgreSQL port
});
exports.default = pool;
