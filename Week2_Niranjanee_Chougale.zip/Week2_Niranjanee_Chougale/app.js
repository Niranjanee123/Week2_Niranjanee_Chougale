"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const body_parser_1 = __importDefault(require("body-parser"));
const pgconfig_1 = __importDefault(require("./pgconfig"));
const service_1 = require("./service");
const app = (0, express_1.default)();
const port = process.env.PORT || 3000;
app.use(body_parser_1.default.json());
app.post('/process-orders', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { items } = req.body;
    if (!items) {
        return res.status(400).json({ error: 'Items list is required' });
    }
    try {
        const filteredOrders = items.filter((order) => !order.orderBlocks.some(block => block.LineNo % 3 === 0));
        const client = yield pgconfig_1.default.connect();
        try {
            yield client.query('BEGIN');
            for (const order of filteredOrders) {
                const { orderID } = order;
                yield client.query('INSERT INTO orders (orderID) VALUES ($1)', [orderID]);
            }
            yield client.query('COMMIT');
            res.status(200).json({ message: 'Orders processed and stored successfully' });
        }
        catch (err) {
            yield client.query('ROLLBACK');
            console.error('Error during transaction:', err);
            res.status(500).json({ error: 'An error occurred while processing the orders' });
        }
        finally {
            client.release();
        }
    }
    catch (err) {
        console.error('Error connecting to database:', err);
        res.status(500).json({ error: 'An error occurred while processing the orders' });
    }
}));
const students = [
    { name: "Alice", age: 20, grade: 75 },
    { name: "Bob", age: 22, grade: 85 },
    { name: "Charlie", age: 21, grade: 60 },
    { name: "David", age: 19, grade: 45 },
    { name: "Eve", age: 20, grade: 90 }
];
app.get('/filter-passed-students', (req, res) => {
    const result = (0, service_1.filterPassedStudents)(students);
    res.json(result);
});
app.get('/get-student-names', (req, res) => {
    const result = (0, service_1.getStudentNames)(students);
    res.json(result);
});
app.get('/sort-students-by-grade', (req, res) => {
    const result = (0, service_1.sortStudentsByGrade)(students);
    res.json(result);
});
app.get('/get-average-age', (req, res) => {
    const result = (0, service_1.getAverageAge)(students);
    res.json(result);
});
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
