"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const body_parser_1 = __importDefault(require("body-parser"));
const app = (0, express_1.default)();
const port = process.env.PORT || 3000;
app.use(body_parser_1.default.json());
app.post('/process-array', (req, res) => {
    const { array } = req.body;
    if (!Array.isArray(array)) {
        return res.status(400).json({ error: 'Array is required' });
    }
    // Concat
    const newArray1 = array.concat([6, 7, 8]);
    console.log("Concat:", newArray1);
    // LastIndexOf
    const lastIndex = array.lastIndexOf(3);
    console.log("LastIndexOf:", lastIndex);
    // Push
    array.push(6);
    console.log("Push:", array);
    // Splice
    const splicedArray = array.splice(1, 2);
    console.log("Splice:", splicedArray);
    // Pop
    const poppedItem = array.pop();
    console.log("Pop:", poppedItem);
    // Slice
    const slicedArray = array.slice(1, 3);
    console.log("Slice:", slicedArray);
    // Map
    const mappedArray = array.map((item) => item * 2);
    console.log("Map:", mappedArray);
    // Shift
    const shiftedItem = array.shift();
    console.log("Shift:", shiftedItem);
    // Filter
    const filteredArray = array.filter((item) => item > 2);
    console.log("Filter:", filteredArray);
    // Unshift
    array.unshift(0);
    console.log("Unshift:", array);
    // ForEach
    array.forEach((item) => console.log("ForEach:", item));
    // Flat
    const nestedArray = [[1, 2], [3, 4], [5, 6]];
    const flattenedArray = nestedArray.flat();
    console.log("Flat:", flattenedArray);
    // Find
    const foundItem = array.find((item) => item === 3);
    console.log("Find:", foundItem);
    // Join
    const joinedString = array.join("-");
    console.log("Join:", joinedString);
    // FindIndex
    const foundIndex = array.findIndex((item) => item === 4);
    console.log("FindIndex:", foundIndex);
    // toString
    const stringRepresentation = array.toString();
    console.log("ToString:", stringRepresentation);
    // Some
    const someResult = array.some((item) => item > 3);
    console.log("Some:", someResult);
    // Split
    const stringToSplit = "Hello World";
    const splitArray = stringToSplit.split(" ");
    console.log("Split:", splitArray);
    // Every
    const everyResult = array.every((item) => item > 0);
    console.log("Every:", everyResult);
    // Replace
    const replacedString = stringToSplit.replace("World", "Universe");
    console.log("Replace:", replacedString);
    // Includes
    const includesResult = array.includes(3);
    console.log("Includes:", includesResult);
    // IndexOf
    const indexOfItem = array.indexOf(2);
    console.log("IndexOf:", indexOfItem);
    res.status(200).json({
        message: 'Array processed successfully',
        results: {
            newArray1,
            lastIndex,
            array,
            splicedArray,
            poppedItem,
            slicedArray,
            mappedArray,
            shiftedItem,
            filteredArray,
            flattenedArray,
            foundItem,
            joinedString,
            foundIndex,
            stringRepresentation,
            someResult,
            splitArray,
            everyResult,
            replacedString,
            includesResult,
            indexOfItem
        }
    });
});
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
