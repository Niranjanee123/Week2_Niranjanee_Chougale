import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.json());

app.post('/process-array', (req: Request, res: Response) => {
    const { array } = req.body;

    if (!Array.isArray(array)) {
        return res.status(400).json({ error: 'Array is required' });
    }

    // Concat
    const newArray1: number[] = array.concat([6, 7, 8]);
    console.log("Concat:", newArray1);

    // LastIndexOf
    const lastIndex: number = array.lastIndexOf(3);
    console.log("LastIndexOf:", lastIndex);

    // Push
    array.push(6);
    console.log("Push:", array);

    // Splice
    const splicedArray: number[] = array.splice(1, 2);
    console.log("Splice:", splicedArray);

    // Pop
    const poppedItem: number | undefined = array.pop();
    console.log("Pop:", poppedItem);

    // Slice
    const slicedArray: number[] = array.slice(1, 3);
    console.log("Slice:", slicedArray);

    // Map
    const mappedArray: number[] = array.map((item: number) => item * 2);
    console.log("Map:", mappedArray);

    // Shift
    const shiftedItem: number | undefined = array.shift();
    console.log("Shift:", shiftedItem);

    // Filter
    const filteredArray: number[] = array.filter((item: number) => item > 2);
    console.log("Filter:", filteredArray);

    // Unshift
    array.unshift(0);
    console.log("Unshift:", array);

    // ForEach
    array.forEach((item: number) => console.log("ForEach:", item));

    // Flat
    const nestedArray: number[][] = [[1, 2], [3, 4], [5, 6]];
    const flattenedArray: number[] = nestedArray.flat();
    console.log("Flat:", flattenedArray);

    // Find
    const foundItem: number | undefined = array.find((item: number) => item === 3);
    console.log("Find:", foundItem);

    // Join
    const joinedString: string = array.join("-");
    console.log("Join:", joinedString);

    // FindIndex
    const foundIndex: number = array.findIndex((item: number) => item === 4);
    console.log("FindIndex:", foundIndex);

    // toString
    const stringRepresentation: string = array.toString();
    console.log("ToString:", stringRepresentation);

    // Some
    const someResult: boolean = array.some((item: number) => item > 3);
    console.log("Some:", someResult);

    // Split
    const stringToSplit: string = "Hello World";
    const splitArray: string[] = stringToSplit.split(" ");
    console.log("Split:", splitArray);

    // Every
    const everyResult: boolean = array.every((item: number) => item > 0);
    console.log("Every:", everyResult);

    // Replace
    const replacedString: string = stringToSplit.replace("World", "Universe");
    console.log("Replace:", replacedString);

    // Includes
    const includesResult: boolean = array.includes(3);
    console.log("Includes:", includesResult);

    // IndexOf
    const indexOfItem: number = array.indexOf(2);
    console.log("IndexOf:", indexOfItem);

    res.status(200).json({
        message: 'Array processed successfully',
        results: {
            newArray1,
            lastIndex,
            array,
            splicedArray,
            poppedItem,
            slicedArray,
            mappedArray,
            shiftedItem,
            filteredArray,
            flattenedArray,
            foundItem,
            joinedString,
            foundIndex,
            stringRepresentation,
            someResult,
            splitArray,
            everyResult,
            replacedString,
            includesResult,
            indexOfItem
        }
    });
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
