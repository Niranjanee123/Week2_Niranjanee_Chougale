// src/pgconfig.ts
import { Pool } from 'pg';

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'week3',
  password: 'postgresql',
  port: 5432,  // Use your PostgreSQL port
});

export default pool;
